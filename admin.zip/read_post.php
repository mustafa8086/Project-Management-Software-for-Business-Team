
<?php include"includes/header.php"; ?>
<!-- Responsive navbar-->

<?php include"includes/nav.php"; ?>


<!-- Page header with logo and tagline-->
<?php include"includes/welcome_header.php"; ?>


<!-- Page content-->
<div class="container">
<div class="row">


<!-- Blog entries-->
<div class="col-lg-8">
<!-- Featured blog post-->


<?php 
//it show only select post

  if(isset($_GET['id'])){

$id=$_GET['id'];
$post= Posts::find_by_id($id);
  }


 ?>

        <!-- Page content-->
        <div class="container">
            <div class="row">
                <!-- Blog entries-->
                <div class="col-lg-12">



                    <!-- Featured blog post-->
                    <div class="card mb-4">
                        <a href="#!"><img class="card-img-top" src="admin/assets/img/posts/<?php echo$post->post_image; ?>" alt="..." /></a>
                        <div class="card-body">
                            <div class="small text-muted"><?php echo $post->assigh_date; ?></div>
                            <h2 class="card-title"><?php echo $post->post_title; ?></h2>
                            <p class="card-text"><?php echo $post->post_content; ?></p>
                            <a class="btn btn-primary" href="index.php">HomePage →</a>
                        </div>
                    </div>



   </div>







</div>
</div>

</div>
</div>

</div>





<!-- Footer-->
<?php include"includes/footer.php"; ?>