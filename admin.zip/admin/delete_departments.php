<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>




<?php 

//delet departmant and to add new activite for deletet post
$activity = new Activity();



if(empty($_GET['id'])){
        header("Location: departments.php");
}


$Departments= Department::find_by_id($_GET['id']);

if($Departments){

$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Delete Departments ID: ".  $Departments->id . " ";
$activity->action_id =  $_GET['id'];
$activity->action_name = "delete";

$activity->save();


    $Departments->delete();
        redirect("departments.php");
        $session->message("Department ID :".$_GET['id']." has been Deleted successfully");  
}else{
        redirect("departments.php");    
}
















 ?>
























<?php include"admin_includes/admin_footer.php"; ?>






