<?php 

class Session{

private $signed_in = false;
public $user_id;
public $message;

//In summary, the constructor initiates a session, checks if a user is logged in,
// and checks for any messages to be displayed to the user.



function __construct(){
	session_start();
	$this->check_the_login();
	$this->check_message();
}



//In summary, this method provides functionality for setting and retrieving messages stored in the session.
// If a message is provided, it is stored in the session, and if no message is provided,
 //it retrieves the previously stored message from the session.


public function message($msg=""){
	if(!empty($msg)){
		$_SESSION['message']= $msg;
	}else{
		return $this->message;
	}
}


//In summary, this method checks for the presence of a message in the session. If a message is found,
// it retrieves and assigns it to a property within the class instance. If no message is found, it sets the property to an empty string. 
//This mechanism allows for the handling of messages across multiple requests or pages.

public function check_message(){
	if(isset($_SESSION['message'])){
		$this->message= $_SESSION['message'];
		unset($_SESSION['message']);
	}else{
		$this->message="";
	}
}



//These functions likely play a role in user authentication and session management within the application. 
//The login() function, in particular,
// handles the process of logging in a user by setting session variables and updating relevant properties.
// The is_signed_in() function allows other parts of the application to check if a user is currently signed in.


public function is_signed_in(){
	return $this->signed_in;
}


public function login($user){
	if($user){
		$this->user_id = $_SESSION['user_id'] = $user->id;
		$this->unique_id = $_SESSION['unique_id'] = $user->unique_id;
		$this->access = $_SESSION['access'] = $user->access;
		$this->signed_in= true;
		$user->status= "Active now";
		$user->save();
	}

}



//In summary, this function removes the user's ID from the session, updates the object's properties accordingly,
 //and sets the signed-in status to false, effectively logging out the user.


public function logout(){
	unset($_SESSION['user_id']);
	unset($this->user_id);
	$this->signed_in= false;
}



//In summary, the check_the_login() function is responsible for checking the user's login status based on 
//the presence of the user_id session variable. If the user is logged in, it updates the object's properties accordingly. 
//Otherwise, it resets the object's properties to reflect that no user is logged in.

private function check_the_login(){
	if(isset($_SESSION['user_id'])){
		$this->user_id = $_SESSION['user_id'];
		$this->signed_in = true;
	}else{

	unset($_SESSION['user_id']);
	$this->signed_in = false;

	}
}



}

$session =  new Session();
$message = $session->message();

?>