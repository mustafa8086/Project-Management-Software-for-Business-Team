<?php 

// require_once("db_object.php");


 class Project extends Db_object {

protected static $db_table = "project";
protected static $db_table_fields= array('project_name', 'project_status', 'created_by' , 'assigh_date', 'due_date','priority','project_image','departments_id');

public $id;
public $project_name;
public $project_status;
public $created_by;
public $assigh_date;
public $due_date;
public $priority;
public $project_image;
public $departments_id;

public $upload_directory = "assets/img/projects";
public $image_placeholder = "http://images.it/site/wp-content/uploads/2014/01/01.jpg";


 public $errors = array();
    public $upload_errors_array = array(
     UPLOAD_ERR_OK         =>"There is no error",
     UPLOAD_ERR_INI_SIZE   =>"The uploaded file exceeds the upload_max_filesize directive in php.ini",
     UPLOAD_ERR_FORM_SIZE  =>"The uploaded file exceeds the MAZ_FILE_SIZE directive that was specified in HTML form",
     UPLOAD_ERR_PARTIAL    =>"The uploaded file was partially uploaded.",
     UPLOAD_ERR_NO_FILE    =>"No file uploaded.",
     UPLOAD_ERR_NO_TMP_DIR =>"Missing a temporary folder.",
     UPLOAD_ERR_CANT_WRITE =>"Failed to write file to disk.",
     UPLOAD_ERR_EXTENSION  =>"A php extension stopped the file upload.",
     );
    //this is passing $_FILES['uploaded_files'] as an argument


//In summary, this method serves to provide the path to //
//the project image file or a placeholder image based on whether the project image property is set or not.


public function image_path_and_placeholder(){

    return empty($this->project_image) ? $this->image_placeholder : "assets/img/projects/$this->project_image";

}


//In summary, this method serves to validate and set the properties related to 
//the uploaded file within the context of the class it belongs to, while also handling any errors that may occur during the process.

public function set_file($file){
                if(empty($file) || !$file || !is_array($file)){
                $this->errors[] = "there was  no file uploaded here";
                return false;}


                elseif($file['error'] !=0){
                $this->errors[] = $this->upload_errors_array[$file['errors']];
                return false;}

                else {
                $this->project_image =  basename($file['name']);
                $this->tmp_path = $file['tmp_name'];
                $this->type = $file['type'];
                $this->size = $file['size'];}

                }



//In summary, this method handles the saving of user data along with an associated project image,
// performing various checks and error handling to ensure the process is executed correctly.                

 public function save_user_and_image() {
          
                        if(!empty($this->errors))
                        {
                                return false;
                        }
                        if(empty($this->project_image) || empty($this->tmp_path))
                        {
                                $this->errors[] = "the file was not available";
                                return false;
                        }
                        $target_path = "assets/img/projects/$this->project_image";

                        if(file_exists($target_path))
                        {
                                $this->errors[] = "the file {$this->project_image} already exists";
                                return false;
                        }
                        if(move_uploaded_file($this->tmp_path, $target_path))
                        {
                      
                                        unset($this->tmp_path);
                                        return true;
                             
                        }
                        else
                        {
                                $this->errors[] = "the file directory probably does not have permission";
                                return false;
                        }
                        
                }
      


//In summary, this method verifies a user's credentials by querying the database for a matching username and password.
 //If a matching user is found, it returns the corresponding user object; otherwise, it returns false.


public static function verify_user($username,$password){
global $database;

$username = $database->escape_string($username);
$password = $database->escape_string($password);

$sql= "SELECT * FROM " . self::$db_table . " WHERE username='{$username}' AND password='{$password}' LIMIT 1";

$the_result_array = self::find_by_query($sql);
return !empty($the_result_array) ? array_shift($the_result_array) : false;

}




//In summary, this method provides a way to retrieve an associative array containing the properties of the class instance, mapped to their corresponding database fields. 
//This can be useful for various operations within the class, such as database interactions.

protected function properties(){

$properties= array();


 foreach (self::$db_table_fields as $db_field) {

                if(property_exists($this,$db_field)){

                $properties[$db_field]= $this->$db_field;

}

 }
 return $properties;

}









}










?>



