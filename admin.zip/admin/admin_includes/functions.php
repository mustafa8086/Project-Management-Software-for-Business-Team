<?php 





//The classAutoLoader function is registered as an autoloader using spl_autoload_register,//
// which ensures that it is invoked whenever a class is referenced but not yet defined in the script.


function classAutoLoader($class){


	$class = strtolower($class);

	$the_path = "includes/{$class}.php";


	if(file_exists($the_path)){
		require_once($the_path);
	}else{
		die("The File name {$class}.php was not found");
	}

}



spl_autoload_register('classAutoLoader');










function redirect($location){
	header("Location: {$location}");
}

?>