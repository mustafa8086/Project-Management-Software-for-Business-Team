//sidepar list 

      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="../index.php"> <img alt="image" src="assets/img/logo.png" class="header-logo" /> <span
                class="logo-name">Admin</span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown active">
              <a href="index.php" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>

        
           
<li><a class="nav-link" href="projects.php"><i data-feather="layout"></i><span>Projects</span></a></li>

<li><a class="nav-link" href="users.php"><i data-feather="mail"></i><span>Chat</span></a></li>
<li><a class="nav-link" href="all_users.php"><i data-feather="grid"></i><span>Users</span></a></li>
<li><a class="nav-link" href="posts.php"><i data-feather="feather"></i><span>Posts</span></a></li>
<li><a class="nav-link" href="departments.php"><i data-feather="command"></i><span>Departments</span></a></li>
<li><a class="nav-link" href="profile.php"><i data-feather="file"></i><span>Profile</span></a></li>
<li><a class="nav-link" href="system_activities.php"><i data-feather="layout"></i><span>System Activity </span></a></li>

          </ul>
        </aside>
      </div>
