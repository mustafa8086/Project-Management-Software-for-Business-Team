<?php 


 require_once("config.php");


class Database {

public $connection;


function __construct(){

	$this->open_db_connection();
}


// open The open_db_connection function establishes a connection to a MySQL database using the mysqli extension.
// If the connection fails, it terminates the script and outputs an error message.


public function open_db_connection(){


	
	$this->connection = new mysqli(DB_HOST,DB_USER,DB_PASS,DB_NAME);


	if($this->connection->connect_errno){
		die("DATABASE connection failed " . $this->connection->connect_error);

	
	}

}

//In summary, this function runs a SQL query on the database, verifies the result, and then returns the result.
 //If there's an error in the query execution, the confirm_query method would handle it


public function query($sql){
		$result = $this->connection->query($sql);
	// $result = mysqli_query($this->connection, $sql);
$this->confirm_query($result);
return $result;
}


/* In summary, this function checks if a SQL query was successful. 
If the query failed, it stops the script and displays an error message. 
If the query was successful, it simply returns the result. */






private function confirm_query($result){
	if(!$result){
			die("QUERY Failed" . $this->connection->error);
}
	return $result;
}


//In summary, this function takes a string, escapes any special characters to make it safe for use in an SQL query,
 //and returns the escaped string.

public function escape_string($string){

	$escapeed_string = $this->connection->real_escape_string($string);

	//$escapeed_string = mysqli_real_escape_string($this->connection,$string);

	return $escapeed_string;
}



//In summary, this function returns the ID of the last row that was inserted into the database using the current MySQL connection.



public function the_insert_id(){
	
	

	return mysqli_insert_id($this->connection);
}


}



//In summary, this code initializes a database object and connects it to the database using the method defined in the Database class.



$database = new Database();

$database->open_db_connection();




?>