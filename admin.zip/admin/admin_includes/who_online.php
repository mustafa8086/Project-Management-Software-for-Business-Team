// show who is online 
        <?php $Users= User::find_all(); ?>     
              <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
                <div class="card">
                  <div class="body">
                     <div id="plist" class="people-list">
                      
                  <div class="card-header">
                    <h4>Who's Online?</h4>
                  </div>
  <?php   foreach ($Users as $User) : ?>
                      <div class="m-b-20">
                        <div id="chat-scroll">
                          <ul class="chat-list list-unstyled m-b-0">
                            <li class="clearfix active">
                              <img src="assets/img/users/<?php echo $User->img; ?>" alt="avatar">
                              <div class="about">
                  <a href="chat.php?user_id=<?php echo $_SESSION['unique_id']; ?>">  <div  class="name"><?php echo $User->username; ?></div></a>
                                <div class="status">

<?php if($User->status == "Offline now" ) 
{ echo "<i class='material-icons offline'>fiber_manual_record</i> Offline now </div>"; }
else{ echo "<i class='material-icons online'>fiber_manual_record</i> Active now </div>"; }
 ?>
                     
                              </div>
                            </li>

                             <?php endforeach; ?>


                      
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
