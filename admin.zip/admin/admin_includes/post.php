<?php 

// require_once("db_object.php");


 class Posts extends Db_object {

protected static $db_table = "posts";
protected static $db_table_fields= array('post_title', 'post_author', 'post_image', 'assigh_date','post_content','post_department_id','post_status','views','post_author_id','tags');

public $id;
public $post_title;
public $post_author;
public $post_image;
public $post_content;
public $post_department_id;
public $post_status;
public $assigh_date;
public $views;
public $post_author_id;
public $tags;
public $upload_directory = "assets/img/posts";
public $image_placeholder = "http://images.it/site/wp-content/uploads/2014/01/01.jpg";




//These methods are likely part of a class responsible for managing posts, 
//particularly for handling file uploads related to posts.


public function image_path_and_placeholder(){

    return empty($this->post_image) ? $this->image_placeholder : "assets/img/posts/$this->post_image";

}



//In summary, this function validates the uploaded file, handles errors, and sets properties related to the file for further processing within the class it belongs 

public function set_file($file){
                if(empty($file) || !$file || !is_array($file)){
                $this->errors[] = "there was  no file uploaded here";
                return false;}


                elseif($file['error'] !=0){
                $this->errors[] = $this->upload_errors_array[$file['errors']];
                return false;}

                else {
                $this->post_image =  basename($file['name']);
                $this->tmp_path = $file['tmp_name'];
                $this->type = $file['type'];
                $this->size = $file['size'];}

                }


//In summary, this function validates the file availability, checks for existing files, 
//attempts to move the uploaded file to the target directory, and handles errors accordingly,
// returning true on successful save and false otherwise.

public function save_user_and_image() {
          
                        if(!empty($this->errors))
                        {
                                return false;
                        }
                        if(empty($this->post_image) || empty($this->tmp_path))
                        {
                                $this->errors[] = "the file was not available";
                                return false;
                        }
                        $target_path = "assets/img/posts/$this->post_image";

                        if(file_exists($target_path))
                        {
                                $this->errors[] = "the file {$this->post_image} already exists";
                                return false;
                        }
                        if(move_uploaded_file($this->tmp_path, $target_path))
                        {
                      
                                        unset($this->tmp_path);
                                        return true;
                             
                        }
                        else
                        {
                                $this->errors[] = "the file directory probably does not have permission";
                                return false;
                        }
                        
                }
      





//In summary, this method provides a way to 
//search for database records based on tags by executing a SQL query and returning the results.

public static function search_by_tags($search){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE tags LIKE '%{$search}%'" );


}



//In summary, this method provides a way to count the number of database records 
//that match a given search term in the tags column of the associated table.

public static function search_count($search){
        
        global $database;
        $sql = "SELECT COUNT(*) FROM ". static::$db_table ." WHERE tags LIKE '%{$search}%' ";
        $result_set = $database->query($sql);

        $row = mysqli_fetch_array($result_set);

        return array_shift($row);
}






//In summary, this method provides a way to retrieve a subset of database records based on pagination and status
// criteria by executing an SQL query with appropriate LIMIT and WHERE clauses.

public static function find_post_by_pages($page_1, $per_page,$status){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE post_status LIKE '%{$status}%' LIMIT $page_1, $per_page ");


}





//In summary, this method provides a way to retrieve database records based on a 
//specified post status by executing an SQL query with an appropriate WHERE clause.



public static function final_post_by($post_status){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE post_status LIKE '%{$post_status}%'");


}



//In summary, this method provides a way to count the number of database records 
//that match a given post status by executing an SQL query with an appropriate WHERE clause.



public static function post_count_by($post_status){
        
        global $database;
        $sql = "SELECT COUNT(*) FROM ". static::$db_table ." WHERE post_status LIKE '%{$post_status}%' ";
        $result_set = $database->query($sql);

        $row = mysqli_fetch_array($result_set);

        return array_shift($row);
}






}










?>



