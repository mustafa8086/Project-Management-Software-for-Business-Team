
            <div class="row">
              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon l-bg-purple">
                    <i class="fas fa-cart-plus"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="padding-20">
                      <div class="text-right">
                        <h3 class="font-light mb-0">
                     <a href="projects.php"><i class="ti-arrow-up text-success"></i> <?php echo Project::count_all(); ?> </a>
                        </h3>
                        <span class="text-muted">Projects</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon l-bg-green">
                    <i class="fas fa-hiking"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="padding-20">
                      <div class="text-right">
                        <h3 class="font-light mb-0">
                            <a href="all_users.php"><i class="ti-arrow-up text-success"></i> <?php echo User::count_all(); ?> </a>
                        </h3>
                        <span class="text-muted">Users</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon l-bg-cyan">
                    <i class="fas fa-chart-line"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="padding-20">
                      <div class="text-right">
                        <h3 class="font-light mb-0">
                        <a href="departments.php"><i class="ti-arrow-up text-success"></i> <?php echo Department::count_all(); ?> </a>
                        </h3>
                        <span class="text-muted">All Departments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>



              <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1">
                  <div class="card-icon l-bg-orange">
                    <i class="fas fa-dollar-sign"></i>
                  </div>
                  <div class="card-wrap">
                    <div class="padding-20">
                      <div class="text-right">
                        <h3 class="font-light mb-0">
                          <a href="posts.php"><i class="ti-arrow-up text-success"></i> <?php echo Posts::count_all(); ?> </a>
                        </h3>
                        <span class="text-muted">Posts</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>