<?php 

// require_once("db_object.php");


 class User extends Db_object {

protected static $db_table = "users";
protected static $db_table_fields= array('unique_id','username', 'password', 'fname', 'lname','img','user_roles','status','email','personal_info','phone','birthday','created_at','access');

public $id;
public $unique_id;
public $username;
public $password;
public $fname;
public $lname;
public $img;
public $user_roles;
public $status;
public $email;
public $personal_info;
public $phone;
public $birthday;
public $created_at;
public $access;
public $upload_directory = "assets/img/users";
public $image_placeholder = "http://images.it/site/wp-content/uploads/2014/01/01.jpg";


 public $errors = array();
    public $upload_errors_array = array(
     UPLOAD_ERR_OK         =>"There is no error",
     UPLOAD_ERR_INI_SIZE   =>"The uploaded file exceeds the upload_max_filesize directive in php.ini",
     UPLOAD_ERR_FORM_SIZE  =>"The uploaded file exceeds the MAZ_FILE_SIZE directive that was specified in HTML form",
     UPLOAD_ERR_PARTIAL    =>"The uploaded file was partially uploaded.",
     UPLOAD_ERR_NO_FILE    =>"No file uploaded.",
     UPLOAD_ERR_NO_TMP_DIR =>"Missing a temporary folder.",
     UPLOAD_ERR_CANT_WRITE =>"Failed to write file to disk.",
     UPLOAD_ERR_EXTENSION  =>"A php extension stopped the file upload.",
     );
    //this is passing $_FILES['uploaded_files'] as an argument


//This method is likely used in web applications to dynamically generate 
//the path to display a user's image or a placeholder image in the user interface.

public function image_path_and_placeholder(){

    return empty($this->img) ? $this->image_placeholder : "assets/img/users/$this->img";

}

//This function is typically used in a file upload process to prepare the uploaded file for further processing or storage.


public function set_file($file){
                if(empty($file) || !$file || !is_array($file)){
                $this->errors[] = "there was  no file uploaded here";
                return false;}


                elseif($file['error'] !=0){
                $this->errors[] = $this->upload_errors_array[$file['errors']];
                return false;}

                else {
                $this->img =  basename($file['name']);
                $this->tmp_path = $file['tmp_name'];
                $this->type = $file['type'];
                $this->size = $file['size'];}

                }


//This function is typically used in a user registration or profile update process to handle the uploading and saving of user images.

public function save_user_and_image() {
          
                        if(!empty($this->errors))
                        {
                                return false;
                        }
                        if(empty($this->img) || empty($this->tmp_path))
                        {
                                $this->errors[] = "the file was not available";
                                return false;
                        }
                        $target_path = "assets/img/users/$this->img";

                        if(file_exists($target_path))
                        {
                                $this->errors[] = "the file {$this->img} already exists";
                                return false;
                        }
                        if(move_uploaded_file($this->tmp_path, $target_path))
                        {
                      
                                        unset($this->tmp_path);
                                        return true;
                             
                        }
                        else
                        {
                                $this->errors[] = "the file directory probably does not have permission";
                                return false;
                        }
                        
                }
      





 //This function is commonly used during user login processes to authenticate users based on their provided username and password.               

public static function verify_user($username,$password){
global $database;

$username = $database->escape_string($username);
$password = $database->escape_string($password);

$sql= "SELECT * FROM " . self::$db_table . " WHERE username='{$username}' AND password='{$password}' LIMIT 1";

$the_result_array = self::find_by_query($sql);
return !empty($the_result_array) ? array_shift($the_result_array) : false;

}





//This function is typically used during user registration processes to validate whether a chosen username is already in use by another user.

public static function user_exists_by($username){
global $database;
$sql= "SELECT * FROM users WHERE username='{$username}' LIMIT 1 ";
$result= self::find_by_query($sql);

if(!empty($result)){
      return true;
}else{
 return false;
}


}


//This method facilitates retrieving records from the database associated with a specific user role.

public static function final_all_by($user_roles){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_roles LIKE '%{$user_roles}%'");


}



//This method facilitates retrieving records from the database associated with a specific access level.

public static function final_all_request($access){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE access LIKE '%{$access}%'");


}




//This method is commonly used to determine whether a user has administrative privileges based on their ID.

public static function is_admin($id){
global $database;
$sql= "SELECT * FROM users WHERE id='{$id}' AND user_roles='Admin' LIMIT 1 ";
$result= self::find_by_query($sql);

if(!empty($result)){
      return true;
}else{
 return false;
}


}




//This method is commonly used to determine whether a user has manager privileges based on their ID.

public static function is_manager($id){
global $database;
$sql= "SELECT * FROM users WHERE id='{$id}' AND user_roles='Manager' LIMIT 1 ";
$result= self::find_by_query($sql);

if(!empty($result)){
      return true;
}else{
 return false;
}


}



//This method is useful for obtaining statistics or generating reports related to disabled user accounts within the system based on their access level.



public static function all_disable_acount($access){
        
        global $database;
        $sql = "SELECT COUNT(*) FROM ". static::$db_table ." WHERE access LIKE '%{$access}%' ";
        $result_set = $database->query($sql);

        $row = mysqli_fetch_array($result_set);

        return array_shift($row);
}





}










?>



