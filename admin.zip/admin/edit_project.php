<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>






<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">


// edit project and activity


<?php 

$activity = new Activity();
if(empty($_GET['id'])){
    redirect("projects.php");
}

$Project = Project::find_by_id($_GET['id']);


 ?>  

    <?php  $department = Department::find_by_id($Project->departments_id); ?>






<?php  



$project = Project::find_by_id($_GET['id']);
if(isset($_POST['update_project'])){


if($project){
 $project->project_name = $_POST['project_name'];
 $project->project_status = $_POST['project_status'];
  $project->assigh_date = date('d-m-y');
 $project->due_date = $_POST['due_date'];
 $project->priority = $_POST['priority'];
 $project->departments_id = $_POST['departments_id'];


if(empty($_FILES['project_image'])){
    $project->save();




$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update successfully Project ID: ".  $project->id . " ";
$activity->action_id = $project->id; 
$activity->action_name = "update";
$activity->save();




    redirect("projects.php");
     $session->message("Project ID: ".$_GET['id']." has been Updated successfully");
}else{

$project->set_file($_FILES['project_image']);
$project->save_user_and_image();
$project->save();



$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update successfully Project ID: ".  $project->id . " ";
$activity->action_id = $project->id; 
$activity->action_name = "update";
$activity->save();






redirect("projects.php");
  $session->message("Project ID: ".$_GET['id']." has been Updated successfully");


}

}}


 ?>



<form action=""  method="post" enctype="multipart/form-data" >
            <div class="row">
              <div class="col-12 ">
                <div class="card">
                  <div class="card-header">
                    <h4>Edit Project Details</h4>
                  </div>


                  <div class="card-body">


             <div class="form-group">
                      <label>Project Name</label>
                      <input name="project_name" type="text" class="form-control" value="<?php echo $Project->project_name; ?>">
                    </div>

 
               <div class="form-group">
                      <label>Status</label>
                      <select class="form-control" name="project_status"  >
                     <option>In Progress</option>
                     <option>Complate</option>
                     </select>
                    </div>





             <div class="form-group">
                      <label>Departments</label>
                      <select class="form-control" name="departments_id"  >
                 <?php $Departments= Department::find_all();
            foreach ($Departments as $Department) : 
                     ?>
             <?php echo "<option value='$Department->id'> $Department->title </option>"; ?>        
                     <?php endforeach; ?>
                    </select>
                    </div>
                    

            <div class="form-group">
                      <label>Due Date</label>
                            <div id="summernote"></div>
                            <input  type="date" name="due_date" value="<?php echo $Project->due_date; ?>"   class="default" multiple>
                          </div>


                      <div class="form-group">
                      <label>Priority</label>
                      <select class="form-control" name="priority"  >
                     <option>Low</option>
                     <option>Mid</option>
                     <option>Higth</option>
                     </select>
                    </div>


  
        <button name="update_project" type="submit" class="btn btn-primary">Update Project</button>
       <a  button type="close" href="projects.php" class="btn btn-danger">Cancel</button></a> 



                
              </div>
            </div>

    
              </div>

</form>






      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>

