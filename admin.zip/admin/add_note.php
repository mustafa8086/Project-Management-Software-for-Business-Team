<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>






<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>



//add Solution to task 
 
<?php  


$activity = new Activity();



if(empty($_GET['id'])){
    redirect("projects.php");
}

$Project = Project::find_by_id($_GET['P_id']);



$project_hr= Project_hr::find_by_id($_GET['id']);



if(isset($_POST['update_notes'])){


if($project_hr){



 

 $project_hr->user_id = $_POST['task_user_id'];

 $project_hr->assigh_date = date('d-m-y');

 $project_hr->due_date = $_POST['due_date'];

 $project_hr->status = $_POST['project_status'];
 $project_hr->note = $_POST['solution'];



$project_hr->project_id=$_GET['P_id'];



$project_hr->save();






$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Add solution for Tasks ID: ".  $Project_hr->id . " ";
$activity->action_id = $Project_hr->id; 
$activity->action_name = "Create";
$activity->save();
$session->message("Note has been added successfully");













redirect("tasks.php?id=".$_GET['P_id']);






}




}



 ?>





      <!-- Main Content -->
      <div class="main-content">
        <section class="section">








<form action=""  method="post" enctype="multipart/form-data" >
            <div class="row">
              <div class="col-12 ">
                <div class="card">
                  <div class="card-header">
                    <h4>Add Note Details</h4>
                  </div>
                <div class="card-body">





 


            <div class="form-group">
                      <label>Task Name : <?php echo $project_hr->task_name; ?>" </label>
                      </div>



             <div class="form-group">
                      <label>Project Name : <?php echo $Project->project_name; ?>"</label>
                      </div>

 
               <div class="form-group">
                      <label>Status</label>
                      <select class="form-control" name="project_status"  >
                     <option>In Progress</option>
                     <option>Complate</option>
                     </select>
                    </div>




<div class="form-group col-12">
<label>The solution to the task</label> 
<textarea
name="solution" class="form-control summernote-simple"> <?php echo $project_hr->note;  ?> </textarea>
</div>

 
<!-- 
<div class="form-group">
<label>Attachments</label>
<div id="summernote"></div>
<input  type="file" name="user_file"  class="default" multiple>
</div>

 -->



                  
  
        <button name="update_notes" type="submit" class="btn btn-primary">Update Notes</button>
     
   <a  button type="close" href="tasks.php?id=<?php echo $_GET['P_id']; ?>" class="btn btn-danger">Cancel</button></a> 















</div>
</div>
</div>
</form>










      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>






