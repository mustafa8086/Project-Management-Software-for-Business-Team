<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>






<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">






   <div class="row mt-4">
              <div class="col-12">
              <div class="card">
      <div class="card-body">
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_project_modal">Add Project</button>
     </div>


    
                <div class="card-header">
                  <h4>Projects Table</h4>
                  <div class="card-header-form">
                    <form>
                      <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <div class="input-group-btn">
                          <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>


                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <tr>

                        <th>#</th>
                        <th>Project Id</th>
                        <th>Department</th>
                        <th>Project Name</th>
                        <th>Created by</th>
                        <th>Status</th>
                        <th>Tasks</th>
                        <th>Assigh Date</th>
                        <th>Due Date</th>
                        <th>Priority</th>
                        <th>Action</th>
                        
                      </tr>

                     <?php 
// to viwe all project

                     $Projects= Project::find_all(); 

                 
                


                     ?>

                     <?php $i=1 ?>
                        <?php   foreach ($Projects as $Project) : ?>

                      <tr>
 



                       <td><?php echo $i."-"; $i+=1; ?></td>

                       <td><?php echo $Project->id; ?></td>


                    <?php  $department = Department::find_by_id($Project->departments_id); ?>

                        <td><?php echo $department->title; ?></td>

                        <td><?php echo $Project->project_name; ?></td>


                   <?php $id_user =$Project->created_by; ?>
                     <?php $user = User::find_by_id($id_user); ?>
                                         
                        <td class="text-truncate">
                          <ul class="list-unstyled order-list m-b-0 m-b-0">
      <li class="team-member team-member-sm"><img class="rounded-circle" src="assets/img/users/<?php echo $user->img; ?>" alt="user" data-toggle="tooltip" title="<?php echo $user->username; ?>"
                                data-original-title="Wildan Ahdian"></li>
                                  </ul>
                        </td>

                   <td><?php echo $Project->project_status; ?></td>

                        <td class="text-truncate">
             <a class="btn btn-icon btn-info" data-toggle="tooltip" title="View All" href="tasks.php?id=<?php echo $Project->id;  ?>"><i  class="fas fa-info-circle"></i></a>

                         
                        </td>


 

                       <td><?php echo $Project->assigh_date; ?></td>

                         <td><?php echo $Project->due_date; ?></td>

                        <td>
                          <div class="badge badge-success"><?php echo $Project->priority; ?></div>
                        </td>


                  <td>
       <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Edit" href="edit_project.php?id=<?php echo $Project->id;  ?>"><i  class="fas fa-pencil-alt"></i></a>
      
        <a onclick="javascript: return confirm('Are you sure you want to delete?');" type="submit"  href="delete_project.php?id=<?php echo $Project->id; ?>" class="btn btn-danger btn-action" data-toggle="tooltip" title="Delete"><i class="fas fa-trash"></i></a>
      </td>


                      </tr>
                               <?php endforeach; ?>

                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>




      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>






<?php include"project_modal.php"; ?>

