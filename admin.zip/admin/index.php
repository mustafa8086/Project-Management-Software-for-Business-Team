
<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>



<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">


//dashbord page (backend)
  <header class="py-5 bg-light border-bottom mb-4">
            <div class="container">
                <div class="text-center my-2">
        <h1 class="fw-bolder">Welcome to Dashboard </h1>
                </div>
            </div>
        </header>



        <section class="section">
<?php include"admin_includes/cards.php"; ?>



<?php include"request_list.php"; ?>

  <?php include"tasks_list.php"; ?>    




   <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Admin',     <?php echo User::count_by("Admin"); ?>],
          ['Disable Account',  <?php echo User::all_disable_acount("disable"); ?>],
          ['Employees',  <?php echo User::count_by("Employee"); ?>],
          ['Managers',  <?php echo User::count_by("Manager"); ?>]
         
        ]);

        var options = {
          title: 'All Users',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>


  <div id="piechart_3d" style="width: 900px; height: 500px;"></div>





        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
