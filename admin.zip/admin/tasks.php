<?php include"admin_includes/admin_header.php"; ?>


<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>



<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>





<?php 
//show project and taske all project

if(empty($_GET['id'])){
    redirect("projects.php");
}

$Project = Project::find_by_id($_GET['id']);
$project_hr= Project_hr::find_all_by_project_id($_GET['id']);

 ?>  

<?php  $department = Department::find_by_id($Project->departments_id); ?>



      <!-- Main Content -->
      <div class="main-content">
        <section class="section">




      <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4>Project Name: <?php echo $Project->project_name; ?> </h4>


                  <div class="card-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_task">Create Task</button>
                  </div>

                   <div class="card-header-form">
                    <form>
                      <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <div class="input-group-btn">
                          <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <tr>
                        <th>#</th>
                        <th>ID Task</th>
                        <th>Task Name</th>
                        <th>Created by</th>
                        <th>Member</th>
                        <th>Task Status</th>
                        <th>Assigh Date</th>
                        <th>Due Date</th>
                        <th>Note</th>
                        <th>Priority</th>
                        <th>Action</th>
                      </tr>
                      <tr>

<?php $i=1; ?>
                        <?php     foreach ($project_hr as $project) : ?>
                       


                          <td><?php echo $i."-"; $i+=1; ?></td>

                          <td><?php echo $project->id; ?></td>

                          <td><?php echo $project->task_name; ?></td>
                        



                       <?php $id_user =$project->created_by; ?>
                     <?php $user = User::find_by_id($id_user); ?>
                                         
                        <td class="text-truncate">
                          <ul class="list-unstyled order-list m-b-0 m-b-0">
      <li class="team-member team-member-sm"><img class="rounded-circle" src="assets/img/users/<?php echo $user->img; ?>" alt="user" data-toggle="tooltip" title="<?php echo $user->username; ?>"
                                data-original-title="Wildan Ahdian"></li>
                                  </ul>
                        </td>


                        
                   <?php $user_id =$project->user_id; ?>
               <?php $user = User::find_by_id($user_id); ?>

                 <td class="text-truncate">
                          <ul class="list-unstyled order-list m-b-0 m-b-0">
      <li class="team-member team-member-sm"><img class="rounded-circle" src="assets/img/users/<?php echo $user->img; ?>" alt="user" data-toggle="tooltip" title="<?php echo $user->username; ?>"
                                data-original-title="Wildan Ahdian"></li>
                                  </ul>
                        </td>



                             <td><?php echo $project->status; ?></td>
                        
                              <td><?php echo $project->assigh_date; ?></td>
                            <td><?php echo $project->due_date; ?></td>





<td class="text-truncate">
        <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Add Note" href="add_note.php?id=<?php echo $project->id;  ?>&P_id=<?php echo $Project->id;  ?>"><i  class="fas fa-pencil-alt"></i></a>


</td>
                                  
     <td> <div class="badge badge-success"><?php echo $project->priority; ?></div>  </td>


                  <td>
        <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Edit" href="edit_task.php?id=<?php echo $project->id;  ?>&P_id=<?php echo $Project->id;  ?>"><i  class="fas fa-pencil-alt"></i></a>
      
        <a onclick="javascript: return confirm('Are you sure you want to delete?');" type="submit"  href="delete_task.php?id=<?php echo $project->id; ?>&P_id=<?php echo $Project->id;  ?>" class="btn btn-danger btn-action" data-toggle="tooltip" title="Delete"><i class="fas fa-trash"></i></a>
      </td>


                      </tr>
                     <?php endforeach; ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>


      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>





<?php  
$activity = new Activity();
$Project_hr = new Project_hr();

if(isset($_POST['create_task'])){


if($Project_hr){
 $Project_hr->task_name = $_POST['task_name'];

 $Project_hr->user_id = $_POST['task_user_id'];
 $Project_hr->assigh_date = date('d-m-y');
 $Project_hr->due_date = $_POST['due_date'];
 $Project_hr->status = $_POST['status'];
 $Project_hr->priority = $_POST['priority'];
 $Project_hr->note = "empty";
 $Project_hr->created_by = $_SESSION['user_id'];
$Project_hr->project_id=$_GET['id'];

$Project_hr->save();




$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Add New Task ID: ".  $Project_hr->id . " ";
$activity->action_id = $Project_hr->id; 
$activity->action_name = "Create";

$activity->save();


 $session->message("Tasks has been added successfully");





redirect("tasks.php?id=". $_GET['id']."");



}}


 ?>





        <!-- Modal with form -->
        <div class="modal fade" id="add_task" tabindex="-1" role="dialog" aria-labelledby="formModal"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="formModal">Add Task</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form class="" method="post">


                      <div class="form-group">
                      <label>Task Name</label>
                      <input name="task_name" type="text" class="form-control">
                    </div>

                     <div class="form-group">
                      <label>Status</label>
                      <select class="form-control" name="status"  >
                     <option>In Progress</option>
                     <option>hold</option>
                     </select>
                    </div>


                

             <div class="form-group">
               <label>User</label>
             <select class="form-control" name="task_user_id"  >
                <?php $user = User::find_all();
            foreach ($user as $users) : 
                     ?>
             <?php echo "<option value='$users->id'> $users->username </option>"; ?>        
                     <?php endforeach; ?>
                    </select>
                    </div>


                      <div class="form-group">
                      <label>Priority</label>
                      <select class="form-control" name="priority"  >
                     <option>Low</option>
                     <option>Mid</option>
                     <option>Higth</option>
                     </select>
                    </div>

              

                  <div class="form-group">
                  <label>Due Date</label>
                  <div id="summernote"></div>
                  <input  type="date" name="due_date"  class="default" multiple>
                        </div>



        <button name="create_task" type="submit" class="btn btn-primary">Create Task</button>
        <button class="btn btn-danger">Cancel</button>



                </form>
              </div>
            </div>
          </div>
        </div>





















