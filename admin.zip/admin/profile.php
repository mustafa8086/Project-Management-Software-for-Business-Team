

<?php include"admin_includes/admin_header.php"; ?>







<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">



<?php 



$user = User::find_by_id($_SESSION['user_id']);




if(isset($_POST['update'])){


if($user){
 $user->fname = $_POST['first_name'];
 $user->lname = $_POST['last_name'];
 $user->email = $_POST['user_email'];
 $user->phone = $_POST['phone'];
 $user->username = $_POST['username'];

 $user->birthday = $_POST['birthday'];

 $user->personal_info = $_POST['personal_info'];



 
if(empty($_FILES['user_image'])){
    $user->save();
}else{

$user->set_file($_FILES['user_image']);
$user->save_user_and_image();
$user->save();

redirect("profile.php");

}

}}


 ?>


// show the user profile using seccion id

 <?php $user = User::find_by_id($_SESSION['user_id']);   ?>


          <div class="section-body">
            <div class="row mt-sm-4">
              <div class="col-12 col-md-12 col-lg-4">
                <div class="card author-box">
                  <div class="card-body">
                    <div class="author-box-center">
                      <img alt="image"  src="assets/img/users/<?php echo $user->img; ?>" class="rounded-circle author-box-picture">
                      <div class="clearfix"></div>
                      <div class="author-box-name">
                        <a href="#"><?php echo $user->username; ?></a>
                      </div>
                      <div class="author-box-job">Web Developer</div>
                    </div>
                    <div class="text-center">
                      <div class="author-box-description">
                        <p>
                          <?php echo $user->personal_info ; ?>
                        </p>
                      </div>



           

                      <div class="w-100 d-sm-none"></div>
                    </div>
                  </div>
                </div>







                <div class="card">
                  <div class="card-header">
                    <h4>Personal Details</h4>
                  </div>
                  <div class="card-body">
                    <div class="py-4">
                      <p class="clearfix">
                        <span class="float-left">
                          Birthday 
                        </span>
                        <span class="float-right text-muted">
                          <?php echo $user->birthday ; ?>
                        </span>
                      </p>
                      <p class="clearfix">
                        <span class="float-left">
                          Phone
                        </span>
                        <span class="float-right text-muted">
                         <?php echo $user->phone ; ?>
                        </span>
                      </p>
                      <p class="clearfix">
                        <span class="float-left">
                          Mail
                        </span>
                        <span class="float-right text-muted">
                          <?php echo $user->email ; ?>
                        </span>
                      </p>


              

                    </div>
                  </div>
                </div>

            </div>





              <div class="col-12 col-md-12 col-lg-8">
                <div class="card">
                  <div class="padding-20">

                      <div class="tab-pane fade show active" id="settings" role="tabpanel" aria-labelledby="profile-tab2">
                        <form method="post" class="needs-validation" enctype="multipart/form-data" >
                          <div class="card-header">
                            <h4>Edit Profile</h4>
                          </div>
                          <div class="card-body">


                            <div class="row">
                              <div class="form-group col-md-6 col-12">
                                <label>First Name</label>
                                <input type="text" class="form-control" name="first_name" value="<?php echo $user->fname ; ?>">
                                <div class="invalid-feedback">
                                  Please fill in the first name
                                </div>
                              </div>

                              <div class="form-group col-md-6 col-12">
                                <label>Last Name</label>
                                <input type="text" class="form-control" name="last_name" value="<?php echo $user->lname ; ?>">
                                <div class="invalid-feedback">
                                  Please fill in the last name
                                </div>
                              </div>
                            </div>






                            <div class="row">
                              <div class="form-group col-md-7 col-12">
                                <label>Email</label>
                          <input type="email" class="form-control" name="user_email" value="<?php echo $user->email ; ?> ">
                                <div class="invalid-feedback">
                                  Please fill in the email
                                </div>
                              </div>
                              <div class="form-group col-md-5 col-12">
                                <label>Phone</label>
                                <input type="tel" class="form-control" name="phone" value="<?php echo $user->phone ; ?>">
                              </div>
                            </div>



                    <div class="form-group">

                          <div> <img alt="image" src="assets/img/users/<?php echo $user->img;?>" class="rounded-circle" width="35" data-toggle="tooltip" >
                              </div>

                        <label>User Image</label>
                      
       

                            <div id="summernote"></div>
                            <input  type="file" name="user_image"  class="default" multiple>
                          </div>








                              <div class="row">
                              <div class="form-group col-12">
                                <label>User Name</label> 
                                <input class="form-control"  type="text" name="username"value="<?php echo $user->username ; ?>">
                              </div>
                            </div>





                              <div class="row">
                              <div class="form-group col-12">
                                <label>Birthday</label> 
                                <input class="form-control"  type="date" name="birthday" value="<?php echo $user->birthday ; ?>">
                              </div>
                            </div>


                            <div class="row">
                              <div class="form-group col-12">
                                <label>Personal Information</label> 
                                <textarea
                                 name="personal_info" class="form-control summernote-simple"> <?php echo $user->personal_info ; ?></textarea>
                              </div>
                            </div>






                            <div class="row">





                            </div>





                          </div>
                          <div class="card-footer text-right">
                            <button name="update" type="submit" class="btn btn-primary">Save Changes</button>
                          </div>
                        </form>
                      </div>




                    </div>
                  </div>
                </div>


                
              </div>







            </div>
          </div>







      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
