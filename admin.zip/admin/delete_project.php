<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>


//delet project and add new activity for delet project

<?php 


if(empty($_GET['id'])){
    header("Location: projects.php");
}
$activity = new Activity();
 $Projects= Project::find_by_id($_GET['id']);
if($Projects){
 






$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Delete Project ID: ".  $project->id . " ";
$activity->action_id =  $_GET['id'];
$activity->action_name = "Delete";

$activity->save();



 $Projects->delete();


    redirect("projects.php"); 
    $session->message("Project ID: ".$_GET['id']." has been Deleted successfully");



}else{
    redirect("projects.php"); 
}




 ?>











<?php include"admin_includes/admin_footer.php"; ?>






