 
search Search Engine form  
 
 <div class="card mb-4">
                        <div class="card-header">Search</div>
                        <div class="card-body">
                            <form action="search.php" method="post">
                            <div class="input-group">
                                <input class="form-control" name="search" type="text" placeholder="Enter search term..." aria-label="Enter search term..." aria-describedby="button-search" />
                                <button class="btn btn-primary" type="submit" id="button-search" type="button">Go!</button>
                            </div>
                        </form>
                        </div>
                    </div>