<?php ob_start(); ?>
<?php require_once("admin/admin_includes/inint.php"); ?>



// Overall, this script handles user authentication by verifying the provided username and password against the database records.
// If the credentials are correct, it logs the user in; otherwise, it displays an error message. Additionally
// it checks if the user is already signed in to prevent redundant login attempts.

<?php  


if($session->is_signed_in()){ //  header("Location: admin/index.php"); 
}



if(isset($_POST['submit'])){
    $username = trim($_POST['username']);
   $password = md5(trim($_POST['password']));

$user_found = User::verify_user($username,$password);

if($user_found ){
    $session->login($user_found);
    header("Location: admin/index.php");
}
else{
  echo "
<script type='text/javascript'>
      alert('You Paswword or Username are incorrect');
    </script>          
";

}

}

 else{

    $username="";
    $password="";
    $the_message= "";


}



?>


 <div class="card mb-4">
<div class="card-body">
        <?php if($session->is_signed_in()): ?>
<?php $user = User::find_by_id($_SESSION['user_id']); ?>
             <h4>Logged in as <?php echo $user->username; ?></h4>

             <a href="admin/logout.php" class="btn btn-primary">Logout</a>
             <a href="admin/index.php" class="btn btn-primary">Dashborad</a>
</div></div>
        <?php else: ?>


<div class="card mb-4">
<div class="card-header">Login</div>
<div class="card-body">

     <form action="" method="post">

                <input type="text" class="form-control" name="username" placeholder="Enter your Username">  
                <input type="password" class="form-control" name="password" placeholder="Enter your Password">  
                <button class="btn btn-primary" id="login" type="submit" name="submit">Login</button>
                </form>       

</div>
</div>

   <?php endif; ?>

<!-- 
    <div class="card mb-4">
                <div class="card-header">Login</div>
                <div class="card-body">

                <form action="" method="post">
                <input type="text" class="form-control" name="username" placeholder="Enter your Username">  
                <input type="password" class="form-control" name="password" placeholder="Enter your Password">  
                <button class="btn btn-primary" id="login" type="submit" name="submit">Login</button>
                </form>       
                </div>   
                </div>
 -->